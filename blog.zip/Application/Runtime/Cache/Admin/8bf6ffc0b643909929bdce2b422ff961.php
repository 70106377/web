<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>layui</title>
  
  <link rel="stylesheet" href="/Public/ht/layui/css/layui.css"  media="all">
  <script src="/Public/ht/layui/layui.js" charset="utf-8"></script>
  <script src="/Public/jquery-3.3.1.min.js"></script>
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>

    
<div class="layui-card">
 <!--  <div class="layui-card-header">
  
            
          
  </div> -->
  <div class="layui-card-body">
  <form class="layui-form" action="">
                <div class="layui-form-item">
                    <div class="layui-input-inline" style="width: 80px">
                       <button type="button" class="layui-btn" onclick="openwindow('添加','450px','300px','<?php echo U('add');?>')" >添加</button>
                    </div>
                    <div class="layui-input-inline">
                        <select name="status" lay-verify="">
                            <option value="1">状态</option>
                        </select>
                    </div>
                    <div class="layui-input-inline">
                        <input type="text" name="title" lay-verify="" placeholder="请输入关键字" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-input-inline" style="width: 250px">
                        <button class="layui-btn" lay-submit lay-filter="submit">搜索</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
<table class="layui-hide" id="test" lay-filter="test"></table>
 
<script type="text/html" id="toolbarDemo">
  <div class="layui-btn-container">
    <button class="layui-btn layui-btn-sm" lay-event="getCheckData">获取选中行数据</button>
    <button class="layui-btn layui-btn-sm" lay-event="getCheckLength">获取选中数目</button>
    <button class="layui-btn layui-btn-sm" lay-event="isAll">验证是否全选</button>
  </div>
</script>
 
<script type="text/html" id="barDemo">
  <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit"><i class="layui-icon layui-icon-edit"></i>编辑</a>
  <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><i class="layui-icon layui-icon-delete"></i>删除</a>
</script>
              
          

<script>
layui.use('table', function(){
  var table = layui.table;
  
  table.render({
    elem: '#test'
     ,request: {
    pageName: 'p' //页码的参数名称，默认：page
    ,limitName: 'nums' //每页数据量的参数名，默认：limit
  },
    height: 'full-90'
    ,url: '/index.php/Admin/Notice/index?is_get=1' //数据接口
    ,toolbar: '#toolbarDemo'
    ,title: '用户数据表'
      ,response: {
      statusName: 'status' //规定数据状态的字段名称，默认：code
      ,statusCode: 1 //规定成功的状态码，默认：0
      ,msgName: 'info' //规定状态信息的字段名称，默认：msg
      ,countName: 'count' //规定数据总数的字段名称，默认：count
      ,dataName: 'data' //规定数据列表的字段名称，默认：data
    } 
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field:'id', title:'ID', width:80, fixed: 'left', unresize: true, sort: true}
      ,{field:'notice', title:'公告', edit: 'text'}
  
      ,{field:'create_date', title:'创建',width:170}
      ,{fixed: 'right', title:'操作', toolbar: '#barDemo', width:150}
    ]]
    ,page: true
     ,limit: 30
  });
  
  //头工具栏事件
  table.on('toolbar(test)', function(obj){
    var checkStatus = table.checkStatus(obj.config.id);
    switch(obj.event){
      case 'getCheckData':
        var data = checkStatus.data;
        layer.alert(JSON.stringify(data));
      break;
      case 'getCheckLength':
        var data = checkStatus.data;
        layer.msg('选中了：'+ data.length + ' 个');
      break;
      case 'isAll':
        layer.msg(checkStatus.isAll ? '全选': '未全选');
      break;
    };
  });
  
  //监听行工具事件
  table.on('tool(test)', function(obj){
    var data = obj.data;
    //console.log(obj)
    if(obj.event === 'del'){
      layer.confirm('真的删除行么', function(index){
         var load = layer.load(2);
                $.ajax({
                    url: '<?php echo U('delete');?>',
                    type: "post",
                    data: { id: data.id },
                    dataType: "json",
                    success: function(r) {
                        layer.close(load);
                        if (r.status == 1) {
                            obj.del();
                            layer.msg(r.info, { icon: 1 }, function() {
                                layer.close(index);
                            });
                        } else {
                            layer.msg(r.info, { icon: 2 }); //错误提示
                        }
                    },
                    error: function() {
                        layer.close(load);
                        layer.msg('网络错误！', { icon: 2 }); //错误提示
                    }
                });
      });
    } else if(obj.event === 'edit'){
      layer.open({
        type: 2,
        title: '编辑',
        shadeClose: true,
        shade: 0.8,
        area: ['450px', '300px'],
        content: '<?php echo U('edit');?>?id='+data.id //iframe的url
        ,end: function(){
          window.location.reload(); //刷新当前页面.
          }
      }); 
      // layer.prompt({
      //   formType: 2
      //   ,value: data.email
      // }, function(value, index){
      //   obj.update({
      //     email: value
      //   });
      //   layer.close(index);
      // });
    }
  });
});
function openwindow(tl,w,h,url){
        layer.open({
        type: 2,
        // skin: 'layui-layer-rim', 
        title: tl,
        area: [w, h], 
        content: url,
        end: function(){
         window.location.reload(); //刷新当前页面.
          }
        });
    }
</script>
 </div>
</div>


           
 
</body>
</html>