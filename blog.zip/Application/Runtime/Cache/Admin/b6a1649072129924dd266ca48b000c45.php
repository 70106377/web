<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>layui</title>
  
  <link rel="stylesheet" href="/Public/ht/layui/css/layui.css"  media="all">
  <script src="/Public/ht/layui/layui.js" charset="utf-8"></script>
  <script src="/Public/jquery-3.3.1.min.js"></script>
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>

    
<form class="layui-form" action="/index.php/Admin/Notice/update" method="post" style="margin-top:20px;">
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">公告内容</label>
    <div class="layui-input-block">
      <textarea name="notice" placeholder="请输入公告内容" class="layui-textarea" style="width: 300px;" ></textarea>
    </div>
  </div>
  
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn layui-btn-normal" lay-submit lay-filter="formDemo">提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
  </form>


           
 
<script>
//Demo
layui.use('form', function(){
  var form = layui.form;
  
  //监听提交
  form.on('submit(formDemo)', function(data){
    // layer.msg(JSON.stringify(data.field));
    var load = layer.load(2);
          $.ajax({
          url:'<?php echo U('notice/add');?>',
          type:"post",
          data:data.field,
          dataType:"json",
          success:function(r){
              layer.close(load);
              if (r.status == 1) {
                  layer.msg(r.info, { icon: 1 }, function() {
                      layer.close(index);
                  });
              } else {
                  layer.msg(r.info, { icon: 2 }); //错误提示
              }
          },
          error:function(){
            layer.close(load);
            layer.msg('网络错误！',{icon: 5});//错误提示
          }
        });
    return false;
  });
});
</script> 

</body>
</html>