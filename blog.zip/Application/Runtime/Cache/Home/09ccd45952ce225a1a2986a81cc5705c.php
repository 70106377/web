<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width" />
    <meta name="author" content="www.yanshisan.cn" />
    <meta name="robots" content="all" />
    <title>关于</title>
    <link rel="stylesheet" href="/Public/qd/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="/Public/ht/layui/css/layui.css">
    <link rel="stylesheet" href="/Public/qd/css/master.css" />
    <link rel="stylesheet" href="/Public/qd/css/gloable.css" />
    <link rel="stylesheet" href="/Public/qd/css/nprogress.css" />
    <link rel="stylesheet" href="/Public/qd/css/about.css" />
</head>
<body>
    <div class="header">
    </div>
    <header class="gird-header">
        <div class="header-fixed">
            <div class="header-inner">
                <a href="<?php echo U('index/index');?>" class="header-logo" id="logo">Mr.Wxl</a>
                <nav class="nav" id="nav">
                    <ul>
                        <li><a href="<?php echo U('index/index');?>">首页</a></li>
						<li><a href="<?php echo U('index/message');?>">留言</a></li>
                        <li><a href="<?php echo U('index/diary');?>">日记</a></li>
                        <li><a href="<?php echo U('index/about');?>">关于</a></li>
                    </ul>
                </nav>
                 <?php if(empty($_SESSION['uid'])): ?><a href="#" class="blog-user dr">
               
                    <i class="fa fa-qq"></i>
                    <?php else: ?>
                    <a href="<?php echo U('login/logout');?>" class="blog-user">
                        <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo session('qq');?>&spec=100" alt="<?php echo session('nickname');?>" title="<?php echo session('nickname');?>">
                    </a><?php endif; ?>
                
                <a class="phone-menu">
                    <i></i>
                    <i></i>
                    <i></i>
                </a>
            </div>
        </div>
    </header>
    <div class="doc-container" id="doc-container">
        <div class="about-banner" id="container">
		    <header class="l-top hasAnim arrow-holder">
		        <a data-path-hover="M31.3184948,33.1943359 C36.3357454,28.0664371 44.4728686,28.0690462 49.572124,33.2807584 C54.6360745,38.4563871 54.6061839,46.8782889 49.6566817,51.9369454 L31.318494,69.5197703 L49.6566817,89.71735 C54.6739322,94.8452488 54.6713794,103.161825 49.572124,108.373537 C44.5081735,113.549166 36.267997,113.518616 31.3184948,108.459959 L3.8112137,78.891075 C-1.25273677,73.7154463 -1.2880417,65.3601778 3.8112137,60.1484655 L31.3184948,33.1943359 Z">
		            <svg width="0" height="0">
		                <path fill="#fff" d="M58.9103319,3.8342148C63.9275825,-1.29368407,72.0647057,-1.29107495,77.1639611,3.92063726C82.2279116,9.09626594,82.198021,17.5181678,77.2485188,22.5768242C77.2485188,22.5768242,31.318494,69.5197703,31.318494,69.5197703C31.318494,69.5197703,77.2485188,116.462716,77.2485188,116.462716C82.2657693,121.590615,82.2632165,129.907191,77.1639611,135.118903C72.1000106,140.294532,63.8598341,140.263982,58.9103319,135.205326C58.9103319,135.205326,3.8112137,78.891075,3.8112137,78.891075C-1.25273677,73.7154463,-1.2880417,65.3601778,3.8112137,60.1484655C3.8112137,60.1484655,58.9103319,3.8342148,58.9103319,3.8342148C58.9103319,3.8342148,58.9103319,3.8342148,58.9103319,3.8342148"></path>
		            </svg>
		        </a>
		        <a data-path-hover="M31.3184948,33.1943359 C36.3357454,28.0664371 44.4728686,28.0690462 49.572124,33.2807584 C54.6360745,38.4563871 54.6061839,46.8782889 49.6566817,51.9369454 L31.318494,69.5197703 L49.6566817,89.71735 C54.6739322,94.8452488 54.6713794,103.161825 49.572124,108.373537 C44.5081735,113.549166 36.267997,113.518616 31.3184948,108.459959 L3.8112137,78.891075 C-1.25273677,73.7154463 -1.2880417,65.3601778 3.8112137,60.1484655 L31.3184948,33.1943359 Z">
		            <svg width="0" height="0">
		                <path fill="#fff" d="M58.9103319,3.8342148 C63.9275825,-1.29368407 72.0647057,-1.29107495 77.1639611,3.92063726 C82.2279116,9.09626594 82.198021,17.5181678 77.2485188,22.5768242 L31.318494,69.5197703 L77.2485188,116.462716 C82.2657693,121.590615 82.2632165,129.907191 77.1639611,135.118903 C72.1000106,140.294532 63.8598341,140.263982 58.9103319,135.205326 L3.8112137,78.891075 C-1.25273677,73.7154463 -1.2880417,65.3601778 3.8112137,60.1484655 L58.9103319,3.8342148 Z"></path>
		            </svg>
		        </a>
		    </header>
		    		    <div class="about-title">
		        <h1>关于我</h1>
		        <p>听过很多大道理，依然过不好这一生</p>
		    </div>
		</div>
		<div class="container-fixed">
    <div class="container-inner">
        <article>
            <section>
                <h1>关于我</h1>
                <ul>
                    <li>姓 名 ：王秀龙
                    </li><li>年 龄 ：20
                    </li><li>性 别 ：男
                    </li><li>住 址 ：现居淮南
                </li></ul>
                <p>
                    00 后 PHP 码农，虽学艺不精，好在力求上进，略懂前段，主攻后端，平时喜欢探索新的知识领域，憧憬着有一天也能进个 BAT 这样的大公司 <img src="/Public/ht/layui/images/face/2.gif" alt="[哈哈]">
                    经济就不再是大问题了 <img src="/Public/ht/layui/images/face/44.gif" alt="[阴险]">
                </p>
            </section>
            <section>
                <h1>爱好</h1>
                <p>
                    足球，下棋，撸码，打游戏，看电影、，睡觉，其它的新鲜玩意儿都想尝试下 <img src="/Public/ht/layui/images/face/28.gif" alt="[馋嘴]">
                </p>
            </section>
            <section>
                <h1>联系方式</h1>
                <ul>
                    <li>企 鹅 ：<a href="http://wpa.qq.com/msgrd?v=3&uin=1665009812&site=qq&menu=yes" target="_blank">1665009812</a></li>
                    <li>邮 箱 ：<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=CGByYntiSHl5JmtnZQ" target="_blank"> 1665009812@qq.com</a></li>
                    <li>微 信 ：</li>
                </ul>
                <figure>
                    <img class="wechat-QR-code-img" src="/Public/images/weixin.png">
                </figure>
            </section>
            <section>
                <h1>关于本站</h1>
                <ul>
                    <li>
                        本站建于2019年5月，主要用于记录学习笔记，技术分享、交流。
                    </li>
                    <li>
                        特别鸣谢 <a href="https://www.layui.com/" target="_blank"><code>layui</code></a> 社区所贡献的开源前端组件
                        以及<code>燕十三</code></a> 提供的如此精美的前端模版
                    </li>
                    <li>
                        网站前端采用 <code>layui</code> 组件以及 <code>燕十三</code> 提供的模版，后端采用 <code>thinkphp + MYSQL</code> 高性能框架作为驱动
                    </li>
                    
                    <li>
                        本站文章仅代表个人观点，和任何组织或个人无关。
                    </li>
                </ul>
            </section>
            <section>
               <!--  <div>
                    <img src="__STATIC__/blog/image/about.jpg" style="width:100%;height:600px;">
                </div> -->
            </section>
        </article>
    </div>
</div>
    <footer class="grid-footer">
        <div class="footer-fixed">
            <div class="copyright">
                <div class="info">
                    <div class="contact">
                        <a href="javascript:void(0)" class="github" target="_blank"><i class="fa fa-github"></i></a>
                        <a href="http://wpa.qq.com/msgrd?v=3&uin=1665009812&site=qq&menu=yes" class="qq" target="_blank" title="1665009812"><i class="fa fa-qq"></i></a>
                        <a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=CGByYntiSHl5JmtnZQ" class="email" target="_blank" title="1665009812@qq.com"><i class="fa fa-envelope"></i></a>
                        <a href="javascript；" class="weixin"><i class="fa fa-weixin"></i></a>
                    </div>
                    <p class="mt05">
                        Copyright &copy; 2019-2019 王秀龙 All Rights Reserved V.2.0.0 皖ICP备19005551号
                    </p>
                </div>
            </div>
        </div>
    </footer>
  <script type="text/javascript" src="/Public/ht/layui/layui.js"></script>
    <script src="/Public/qd/js/yss/gloable.js"></script>
    <script src="/Public/qd/js/plugins/nprogress.js"></script>
    <script>NProgress.start();</script>
   	<script src="/Public/jquery-3.3.1.min.js"></script>
 	<script src="/Public/qd/js/plugins/blogbenoitboucart.min.js"></script>
    <script> 
        window.onload = function () {
            NProgress.done();
        };
    </script>
</body>
</html>