<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width" />
    <title>日记</title>
    <link rel="stylesheet" href="/Public/qd/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/Public/ht/layui/css/layui.css">
    <link rel="stylesheet" href="/Public/qd/css/master.css" />
    <link rel="stylesheet" href="/Public/qd/css/gloable.css" />
    <!-- <link rel="stylesheet" href="/Public/qd/css/nprogress.css" />
    <link rel="stylesheet" href="/Public/qd/css/blog.css" /> -->
    <link rel="stylesheet" href="/Public/qd/css/diary.css">
    <!-- <script scr='https://www.yanshisan.cn/bundles/timeline?v=blHLCsaUDbIHlOz4I-DAoN3gOIaCAE4bAAThuB62NBo1'></script> -->
</head>
<body>
    <div class="header">
    </div>
    <header class="gird-header">
        <div class="header-fixed">
            <div class="header-inner">
                <a href="<?php echo U('index/index');?>" class="header-logo" id="logo">Mr.Wxl</a>
                <nav class="nav" id="nav">
                   <ul>
                        <li><a href="<?php echo U('index/index');?>">首页</a></li>
                        <li><a href="<?php echo U('index/message');?>">留言</a></li>
                        <li><a href="<?php echo U('index/diary');?>">日记</a></li>
                        <li><a href="<?php echo U('index/about');?>">关于</a></li>
                    </ul>
                </nav>
                <?php if(empty($_SESSION['uid'])): ?><a href="#" class="blog-user dr">
               
                    <i class="fa fa-qq"></i>
                    <?php else: ?>
                    <a href="<?php echo U('login/logout');?>" class="blog-user">
                        <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo session('qq');?>&spec=100" alt="<?php echo session('nickname');?>" title="<?php echo session('nickname');?>">
                    </a><?php endif; ?>
                <a class="phone-menu">
                    <i></i>
                    <i></i>
                    <i></i>
                </a>
            </div>
        </div>
    </header>
    <div class="doc-container" id="doc-container">
        <div class="container-fixed">
            <div class="col-content" style="width:100%">
                <div class="inner">
                    <article class="article-list">
                        <input type="hidden" value="@Model.BlogTypeID" id="blogtypeid" />
                        <section class="article-item">
                           

<div class="timeline-box shadow">
        <div class="timeline-main">
            <h1><i class="fa fa-clock-o"></i>日记</h1>
            <div class="timeline-line"></div>
                    <div class="timeline-year">
                        <h2><a class="yearToggle">2019 年</a><i class="fa fa-caret-down fa-fw"></i></h2>
                        <div class="timeline-month">
     <ul>
     <?php if(is_array($diary)): $i = 0; $__LIST__ = $diary;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
            <div class="h4 animated fadeInLeft">
                <p class="date"><?php echo ($vo["date"]); ?></p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight"><?php echo ($vo["notice"]); ?></div>
            <div class="clear"></div>
        </li><?php endforeach; endif; else: echo "" ;endif; ?>
       <li>
            <div class="h4 animated fadeInLeft">
                <p class="date">05月02日</p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight">博客2.0正式上线。&nbsp; &nbsp;--2019年05月02号</div>
            <div class="clear"></div>
        </li>
        <li>
            <div class="h4 animated fadeInLeft">
                <p class="date">04月18日</p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight">累了就好好睡上一觉</div>
            <div class="clear"></div>
        </li>
        <li>
            <div class="h4 animated fadeInLeft">
                <p class="date">03月09日</p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight">博客正式上线，这也是我第一个网站。&nbsp; &nbsp;--2019年3月09号</div>
            <div class="clear"></div>
        </li>
        <li>
            <div class="h4 animated fadeInLeft">
                <p class="date">01月26日</p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight"><p>林俊杰 ：像我这种自己编曲制作自己打鼓 拉麦四五十厘米高音十五秒不带换气还自带混响的人……</p></div>
            <div class="clear"></div>
        </li>
        <li>
            <div class="h4 animated fadeInLeft">
                <p class="date">01月22日</p>
            </div>
            <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
            <div class="content animated fadeInRight"><p>子夜的灯是一条未穿衣裳的小河，你的信像一尾鱼游来。读江河如读一面镜，读手中的信如见你的笑。</p></div>
            <div class="clear"></div>
        </li>

		</ul>
        </div>
        </div>
        <div class="timeline-year">
            <h2><a class="yearToggle">2018 年</a><i class="fa fa-caret-down fa-fw"></i></h2>
            <div class="timeline-month">
            <ul>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">10月15日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight">我第一次开始接触PHP,写出了helow word。</div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">08月12日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight">花光所有运气遇见你。</div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">08月10日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p><span>没人在乎你怎样在深夜痛哭，也没人在乎你辗转反侧的要熬几个秋。外人只看结果，自己要独撑过程。等我们都明白了这个道理，便不会再在人前矫情，四处诉说以求宽慰。</span></p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">06月28日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p><span>当你的才华还撑不起你的野心时，那你就应该静下心来学习。</span></p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">06月26日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p>6.29 江湖再见</p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">05月24日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p><span>林花谢了春红，太匆匆，无奈朝来寒雨晚来风。</span><span>胭脂泪，相留醉，几时重？自是人生长恨水长东。&nbsp; &nbsp;&nbsp;</span><span>——李煜《相见欢》</span></p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">05月04日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p style="text-align: left;"><span>今生今世，我们所走的路都错了，时间不对，地点也不对&nbsp; &nbsp; &nbsp;</span>来生，我们再会，来生，我会等你&nbsp; &nbsp;&nbsp;<span style="text-align: right;">——</span>爱有来生</p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">05月03日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p><span>人面不知何处去，桃花依旧笑春风。</span><span class="c-gray c-gap-left-small op-imprecise-author">&nbsp;——</span>崔护《题都城南庄》</p></div>
                <div class="clear"></div>
            </li>
            <li>
                <div class="h4 animated fadeInLeft">
                    <p class="date">04月13日</p>
                </div>
                <p class="dot-circle animated "><i class="fa fa-dot-circle-o"></i></p>
                <div class="content animated fadeInRight"><p>我第一次到淮南，带着所以的希望和自信来这里。</p></div>
                <div class="clear"></div>
            </li>
                
            </ul>
        </div>
    </div>
            <h1 style="padding-top:4px;padding-bottom:2px;margin-top:40px;"><i class="fa fa-hourglass-end"></i>THE END</h1>
        </div>
    </div>

                        </section>
                    </article>
                </div>
            </div>
        </div>
    </div>
  <footer class="grid-footer">
        <div class="footer-fixed">
            <div class="copyright">
                <div class="info">
                    <div class="contact">
                        <a href="javascript:void(0)" class="github" target="_blank"><i class="fa fa-github"></i></a>
                        <a href="http://wpa.qq.com/msgrd?v=3&uin=1665009812&site=qq&menu=yes" class="qq" target="_blank" title="1665009812"><i class="fa fa-qq"></i></a>
                        <a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=CGByYntiSHl5JmtnZQ" class="email" target="_blank" title="1665009812@qq.com"><i class="fa fa-envelope"></i></a>
                        <a href="javascript；" class="weixin"><i class="fa fa-weixin"></i></a>
                    </div>
                    <p class="mt05">
                        Copyright &copy; 2019-2019 王秀龙 All Rights Reserved V.2.0.0 皖ICP备19005551号
                    </p>
                </div>
            </div>
        </div>
    </footer>
    <script type="text/javascript" src="/Public/ht/layui/layui.js"></script>
    <script src="/Public/qd/js/yss/gloable.js"></script>
    <script src="/Public/qd/js/plugins/nprogress.js"></script>
    <script src="/Public/qd/js/pagecomment.js"></script>
    <script>NProgress.start();</script>
    <script> 
        window.onload = function () {
            NProgress.done();
        };
    </script>
</body>
</html>