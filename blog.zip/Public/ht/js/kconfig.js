/** k_admin-v1.1.0 MIT License By http://k/zhengjinfan.cn e-mail:zheng_jinfan@126.com */
 ;layui.define(function(exports) {

    var kconfig = {
        resourcePath: '/themes/erpadmin_layui/public/assets/lib/layui-lib/', 
    };

    exports('kconfig', kconfig);
});