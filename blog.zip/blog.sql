﻿# Host: localhost  (Version: 5.5.53)
# Date: 2019-08-31 16:00:55
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "tp3_activity"
#

DROP TABLE IF EXISTS `tp3_activity`;
CREATE TABLE `tp3_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(50) DEFAULT NULL COMMENT '标题',
  `text` text COMMENT '内容',
  `level` varchar(20) DEFAULT NULL COMMENT '级别',
  `scope` varchar(60) DEFAULT NULL COMMENT '参赛范围',
  `number` varchar(20) DEFAULT NULL COMMENT '报名人数',
  `photo` varchar(200) DEFAULT NULL COMMENT '图片',
  `bm_time` varchar(60) DEFAULT NULL COMMENT '报名时间',
  `hd_time` varchar(60) DEFAULT NULL COMMENT '活动时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Data for table "tp3_activity"
#

/*!40000 ALTER TABLE `tp3_activity` DISABLE KEYS */;
INSERT INTO `tp3_activity` VALUES (1,'2019大学生摄影大赛','\"亚洲大学生摄影大赛\"由亚洲教育北京论坛和中国青年报社于2006年联合发起，2008年中国高校传媒联盟作为主办单位之一，参加了影展。摄影展旨在弘扬源远流长的亚洲文化。','院级','不限','不限','https://7376-svip9-1258873690.tcb.qcloud.la/1559706346209-5102236.png?sign=0a5d1b9778f92e76d208e1aa89d509ed&t=1560046045','2019-06-10 - 2019-06-20','2019-06-21 - 2019-06-30',NULL),(2,'青年羽毛球活动','生命不息 运动不止 这句口号 一直号召着我们 保持积极向上的生活状态 然而 在乌压压大城市生活的你 每天八小时盯着电脑手机的你 下班回家只想来个“葛优瘫”的你 会不会觉得被这座城市压得喘不过气来? 很多人想出去看看走走 也想像童年那样蹦蹦跳跳 但熬了一夜有一夜，赖了一床又一床 却始终走不出自己给自己套的枷锁 友觅特别想帮你走向现实的生活 在这个冰冷的城市里能给你一丝温暖 所以你来吧！让自己运动起来吧！ 羽毛球相信是能够让最多的人 感受到运动带来的激情 和积极向上的健康运动项目了','系级','不限','不限','https://7376-svip9-1258873690.tcb.qcloud.la/1559705912236-1577859.png?sign=1873ab13af64549f196305c61458e825&t=1560046148','2019-06-10 - 2019-06-20','2019-06-21 - 2019-06-30',NULL);
/*!40000 ALTER TABLE `tp3_activity` ENABLE KEYS */;

#
# Structure for table "tp3_blog"
#

DROP TABLE IF EXISTS `tp3_blog`;
CREATE TABLE `tp3_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) DEFAULT NULL,
  `text` text,
  `photo` varchar(255) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` int(11) DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Data for table "tp3_blog"
#

/*!40000 ALTER TABLE `tp3_blog` DISABLE KEYS */;
INSERT INTO `tp3_blog` VALUES (1,'博客2.0已上线','博客2.0已经发布到服务器，可以正式访问了，欢迎大家提交bug',NULL,'2019-05-02 21:45:01',2),(2,' 数据接收三种方式','        数据接收三种方式：\r\n\t$name=$_post[\'name\']\r\n\t$name=$_get[\'name\']\r\n\t$name=$_requset[\'name\'}',NULL,'2019-05-02 21:45:59',2),(3,'获取QQ头像','根据QQ获取QQ头像http://q4.qlogo.cn/headimg_dl?dst_uin=1665009812&amp;spec=100',NULL,'2019-05-02 21:47:26',2),(4,'layui弹出层','\t\t//clss=\'boke\'的单机事件\r\n\t\t$(\'.boke\').on(\'click\', function(){\r\n\t\t layer.open({\r\n\t\t  type: 2,\r\n\t\t  title: \'标题\',\r\n\t\t  shadeClose: true,\r\n\t\t  shade: 0.8,\r\n\t\t  area: [\'50%\', \'80%\'],\r\n\t\t  content: \'{:U(\'index/index\')}\' //iframe的url\r\n\t\t}); \r\n\t\t});',NULL,'2019-05-02 21:48:42',2),(5,'时间戳转换','1. UNIX时间戳转换为日期用函数： date() \r\n一般形式：date(\'Y-m-d H:i:s\', 1156219870); \r\n2. 日期转换为UNIX时间戳用函数：strtotime() \r\n一般形式：strtotime(\'2010-03-24 08:15:42\')； ',NULL,'2019-05-02 21:49:31',2),(6,'判断是否选中下拉列表框','&lt;if condition=&quot;$vo[\'uid\'] eq $aa[\'id\']&quot;&gt;selected &lt;/if&gt;',NULL,'2019-05-02 21:50:39',2),(7,'多表查询方法','alias用于设置当前数据表的别名，便于使用其他的连贯操作例如join方法等。\r\n\r\n示例：\r\n\r\n$Model = M(\'User\');\r\n$Model-&gt;alias(\'a\')-&gt;join(\'__DEPT__ b ON b.user_id= a.id\')-&gt;select();\r\n最终生成的SQL语句类似于：\r\n\r\nSELECT * FROM think_user a INNER JOIN think_dept b ON b.user_id= a.id',NULL,'2019-05-02 21:51:23',2),(8,'浮动和清除浮动','.fd\r\n{\r\n\tfloat:left;\r\n\twidth:110px;\r\n\theight:90px;\r\n\tmargin:5px;\r\n}\r\n.qcfd\r\n{\r\n\tclear:both;\r\n\tmargin-bottom:2px;\r\n}',NULL,'2019-05-02 21:52:32',2),(9,'padding内边距','（1）padding-left:10px; 左内边距\r\n\r\n（2）padding-right:10px; 右内边距\r\n\r\n（3）padding-top:10px; 上内边距\r\n\r\n（4）padding-bottom:10px; 下内边距\r\n\r\n（5）padding：10px; 四边统一内边距\r\n\r\n（6）padding:10px 20px; 上下、左右内边距\r\n\r\n（7）padding:10px 20px 30px; 上、左右、下内边距\r\n\r\n（8）padding:10px 20px 30px 40px; 上、右、下、左内边距',NULL,'2019-05-02 21:53:10',2),(10,'margin','（1）margin-left:10px; 左外边距\r\n\r\n（2）margin-right:10px; 右外边距\r\n\r\n（3）margin-top:10px; 上外边距\r\n\r\n（4）margin-bottom:10px; 下外边距\r\n\r\n（5）margin:10px; 四边统一外边距\r\n\r\n（6）margin:10px 20px; 上下、左右外边距\r\n\r\n（7）margin:10px 20px 30px; 上、左右、下外边距\r\n\r\n（8）margin:10px 20px 30px 40px; 上、右、下、左外边距',NULL,'2019-05-02 21:53:25',2),(11,'layui监听异步提交数据',' form.on(\'submit(formDemo)\', function(data){\r\n   var load = layer.load(2);\r\n          $.ajax({\r\n          url:\'{:U(\'index/insert\')}\',\r\n          type:&quot;post&quot;,\r\n          data:data.field,\r\n          dataType:&quot;json&quot;,\r\n          success:function(r){\r\n              layer.close(load);\r\n              if (r.status == 1) {\r\n                  layer.msg(r.info, { icon: 1 }, function() {\r\n                      // layer.close(index);\r\n                   window.location.reload();\r\n                  });\r\n              } else {\r\n                  layer.msg(r.info, { icon: 2 }); //错误提示\r\n              }\r\n          },\r\n          error:function(){\r\n            layer.close(load);\r\n            layer.msg(\'网络错误！\',{icon: 5});//错误提示\r\n          }\r\n        });\r\n    return false;\r\n  });',NULL,'2019-05-02 21:54:00',2),(12,'js页面跳转','window.location.href=r.data.url;  //跳转到指定页面\r\n\r\nwindow.top.location.href=r.data.url; //在当前页面打开',NULL,'2019-05-02 21:56:41',2),(13,'js刷新页面','parent.location.reload();   //js刷新父级页面\r\n\r\nwindow.location.reload();  //js刷新当前页面',NULL,'2019-05-02 21:57:02',2),(14,'判断session.uid是否为空','&lt;empty name=&quot;Think.session.uid&quot;&gt;\r\n登入\r\n&lt;else/&gt;\r\n退出\r\n&lt;/empty&gt;',NULL,'2019-05-02 21:58:14',2),(15,'foreach',' foreach ($list as $key =&gt; $value) {\r\n          $bid=$value[\'id\'];\r\n          $count=M(\'comment\')-&gt;where(&quot;bid=$bid&quot;)-&gt;count();\r\n          $list[$key][\'count\']=$count;\r\n}',NULL,'2019-05-04 21:08:50',2),(17,'ajax',' public function blog(){\r\n        if (I(\'is_get\')) {\r\n            $user_count = M(\'blog\')-&gt;where($where)-&gt;count();\r\n            $Page       = new \\Think\\Page($user_count,I(\'nums\'));// 实例化分页类 传入总记录数和每页显示的记录数(25)\r\n            $user_select = M(\'blog\')-&gt;where($where)-&gt;order(\'id desc\')-&gt;limit($Page-&gt;firstRow.\',\'.$Page-&gt;listRows)-&gt;select();\r\n            $return = array(\r\n                \'status\'=&gt;1,\r\n                \'info\'=&gt;\'成功\',\r\n                \'count\'=&gt;$user_count,\r\n                \'data\'=&gt;$user_select\r\n            );\r\n            $this-&gt;ajaxReturn($return);\r\n        } else {\r\n            $this-&gt;display(\'\');\r\n        }\r\n    }',NULL,'2019-05-15 20:16:47',2),(20,'js实现图片切换','下面写两种情况：\r\n\r\n第一种是先规定几张图片，随机选中其中一个显示\r\n\r\n   /*  &lt;img id=&quot;div_first&quot; src=\'./image/first1.jpg\' style=&quot;width:1348px;height:657px; &quot;/&gt;    */                                                                            // 下面蓝色部分为想要更改的那部分的id属性,我的是这么写的\r\n\r\njs代码：\r\n\r\nvar imgs =[&quot;first1.jpg&quot;, &quot;first2.jpg&quot;, &quot;first3.jpg&quot;];       //（设定想要显示的图片）\r\n        function time(){\r\n               var i = Math.floor(Math.random()*(3+0)+0); //（获取随机数，设置m~n的随机，此处3是代表n，0处是m，可以替换）\r\n               document.getElementById(&quot;div_first&quot;).src =&quot;./image/&quot;+imgs[i];  //红色部分是自定义的图片文件夹目录\r\n\r\n               \r\n\r\n        }setInterval(&quot;time()&quot;,3000);           //设定为3秒，可更换\r\n\r\n\r\n\r\n第二种是规定图片，并按照顺序循环显示\r\n\r\njs代码：\r\n\r\nvar imgs =[&quot;first1.jpg&quot;, &quot;first2.jpg&quot;, &quot;first3.jpg&quot;];    //（设定想要显示的图片）\r\nvar x = 0;        \r\n        function time1(){\r\n               x++;    \r\n               x=x%3;         //         超过2则取余数，保证循环在0、1、2之间\r\n               document.getElementById(&quot;div_first&quot;).src =&quot;./image/&quot;+imgs[x];\r\n        }setInterval(&quot;time1()&quot;,3000);\r\n',NULL,'2019-06-01 17:04:27',2),(23,'js点击跳转','&lt;script&gt;\r\n$(document).ready(function() {\r\n  $(&quot;#p1&quot;).click(function() {   //点击事件\r\n    $(&quot;html, body&quot;).animate({\r\n      scrollTop: $(&quot;#div1&quot;).offset().top }, //跳转位置\r\n       {duration: 500,easing: &quot;swing&quot;});\r\n    return false;\r\n  });\r\n&lt;/script&gt;',NULL,'2019-06-17 19:03:23',2),(24,'vue中引用组件','局部注册组件\r\n先引用\r\nimport User from ‘./components/Uses’\r\n注册\r\ncomponents:{\r\n       &quot;users&quot;:Users  //可以简写 Users\r\n}',NULL,'2019-06-26 08:24:33',2),(25,'VUE全局注册组件','在main.js中\r\n先引用组件Users\r\nimport Users form  &quot;./components/Users&quot;\r\n在全局注册组件\r\nVue.component(&quot;users&quot; ,Users);//前面是名称后面是组件\r\n\r\n调用组件\r\n&lt;users&gt;&lt;/users&gt;\r\n',NULL,'2019-06-26 08:35:56',2),(26,'Vue中v-for指令','&lt;div v-for=&quot;user in users&quot;&gt;\r\n{{user}}\r\n&lt;/div&gt;\r\n\r\nusers:[&quot;hellow&quot;,&quot;你好&quot;,&quot;呵呵&quot;]',NULL,'2019-06-26 08:36:45',2),(31,'JS获取表单数据','表单内容\r\n&lt;input type=&quot;hidden&quot; id=&quot;count&quot; value=&quot;{$fenye.count}&quot;&gt; \r\n&lt;input type=&quot;hidden&quot; id=&quot;curr&quot; value=&quot;{$fenye.curr}&quot;&gt;\r\n\r\nJS内容\r\nvar count=document.getElementById(&quot;count&quot;).value;\r\nvar curr=document.getElementById(&quot;curr&quot;).value;',NULL,'2019-07-23 09:58:01',2),(32,'追加class元素','id=active的单击事件给id=area的追加/删除\r\nstyle中的tiaojian\t\r\n$(&quot;#active&quot;).click(function(){\r\n$(&quot;#area&quot;).toggleClass(&quot;tiaojian&quot;);\r\n$(&quot;#active&quot;).toggleClass(&quot;active&quot;);\r\n});',NULL,'2019-07-23 10:12:52',2),(33,'C语言快捷键','F7 生成解决方案相当于编译、链接\r\n\r\nCtrl+F5  运行（不调试）',NULL,'2019-07-23 11:19:18',2),(34,'第一个C语言程序','#include&lt;stdio.h&gt;\r\nvoid main()//仅且只能有一个，从它开始，到它结束\r\n{\r\nint a=45,b=32;\r\nprintf(&quot;%d\\n&quot;,a+b);\r\n\r\n}',NULL,'2019-08-01 21:29:25',2),(35,'第一章基础','1、goto语句尽量少使用\r\n2、在C语言中，程序的模块化是利用函数实现的\r\n3、C语言仅可编译执行\r\n       编译：全部翻译在执行；解释：翻译一条，执行一条\r\n',NULL,'2019-08-01 21:46:02',2),(36,'c语言','C语言开发过程：编辑--&gt;（.cpp）编译--&gt;(.obj)链接--&gt;可执行文件（exe）',NULL,'2019-08-01 21:54:20',2),(37,'第一章','#define   p 3.14  //定义一个常量 \r\n#开头是命令行，不需要；结束\r\na=3+3  //一个=号是赋值；==等于号是相等\r\n  ',NULL,'2019-08-01 22:12:09',2),(38,'进制转换','八进制（逢八进一，必须以数字0开头）\r\n十进制（逢十进一，前面不能出现0）\r\n十六进制（逢十六进一，必须以0x开头）',NULL,'2019-08-01 22:18:44',2),(39,'第二个C语言','#include&lt;stdio.h&gt;\r\nvoid main(){\r\n\tint a,b;\r\n\ta=45;\r\n\tb=54;\r\n\tprintf(&quot;a+b=%d\\n&quot;,a+b);\r\n\tprintf(&quot;a-b=%d\\n&quot;,a-b);\r\n}',NULL,'2019-08-01 22:39:33',2),(40,'C语言函数','1、sizeof()函数判断数据类型长度\r\n2、\r\n数据类型int：整型   double为实型',NULL,'2019-08-02 09:38:59',2),(42,'页脚','html代码\r\n\r\n&lt;footer class=&quot;footer mt-20&quot;&gt;\r\n\t&lt;div class=&quot;container-fluid&quot;&gt;\r\n\t\t&lt;nav&gt; &lt;a href=&quot;#&quot; target=&quot;_blank&quot;&gt;关于我们&lt;/a&gt; &lt;span class=&quot;pipe&quot;&gt;|&lt;/span&gt; &lt;a href=&quot;#&quot; target=&quot;_blank&quot;&gt;联系我们&lt;/a&gt; &lt;span class=&quot;pipe&quot;&gt;|&lt;/span&gt; &lt;a href=&quot;#&quot; target=&quot;_blank&quot;&gt;法律声明&lt;/a&gt; &lt;/nav&gt;\r\n\t\t&lt;p&gt;Copyright &amp;copy;2016 H-ui.net All Rights Reserved. &lt;br&gt;\r\n\t\t\t&lt;a href=&quot;http://www.miitbeian.gov.cn/&quot; target=&quot;_blank&quot; rel=&quot;nofollow&quot;&gt;京ICP备1000000号&lt;/a&gt;&lt;br&gt;\r\n\t\t&lt;/p&gt;\r\n\t&lt;/div&gt;\r\n&lt;/footer&gt;\r\n\r\ncss代码\r\n\r\n.footer{border-top:1px solid #E8E8E8; padding:15px 0;font-family:tahoma,Arial;font-size:12px;color:#999;line-height:22px;text-align:center}\r\n.footer a,.footer a:hover{color:#999}','','2019-08-15 11:23:41',2);
/*!40000 ALTER TABLE `tp3_blog` ENABLE KEYS */;

#
# Structure for table "tp3_message"
#

DROP TABLE IF EXISTS `tp3_message`;
CREATE TABLE `tp3_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `qq` bigint(20) DEFAULT NULL,
  `message` text,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

#
# Data for table "tp3_message"
#

/*!40000 ALTER TABLE `tp3_message` DISABLE KEYS */;
INSERT INTO `tp3_message` VALUES (1,'管理员',70106377,'<p>博客2.0已上线，<span>欢迎大家提交bug</span></p>','2019-05-02 22:05:47'),(2,'染柒',1665009812,'博客上分享了php相关知识，希望可以帮助大家学习','2019-05-02 22:07:14'),(3,'凉颜',30402409,'有什么不懂得问题都可以留下来，看到会帮你们解决的','2019-05-02 22:08:12'),(4,'陌生人',877033588,'2019年5月3日，博客2.0上传到虚拟主机','2019-05-03 12:55:29'),(5,'没有昵称',630825117,'能否分享一下前端页面模板呢？谢谢','2019-05-07 00:10:55'),(6,'No one',462069352,'后端建议直接尝试TP5.0后的版本','2019-05-07 14:32:36'),(7,'爱我中华',875798675,'20岁，黄金年龄，继续加油','2019-05-07 18:40:01'),(8,'没个性',2019,'特喜欢这样的简约风，请问开源吗？<img src=\"http://hzjsj.top/Public/ht/layui/images/face/1.gif\" alt=\"[嘻嘻]\">','2019-05-07 22:24:38'),(9,'没个性',179141850,'开源的代码？','2019-05-07 23:44:25'),(10,'phper',843611554,'843611554@qq.com&nbsp; &nbsp;能否借鉴一下源码','2019-05-08 10:26:28'),(11,'谢晓峰',308144593,'                308144593@qq.com&nbsp; 前端源码有吗<br>','2019-05-08 11:37:03'),(12,'管理员',1665009812,'前端代码开源，喜欢的可以联系我','2019-05-08 11:42:35'),(13,'天霸',732128096,'范德萨发顺丰','2019-05-08 11:44:15'),(14,'admin',839650216,'lihai','2019-05-08 14:49:21'),(15,'啊啊啊啊',1746671042,'貌似看见了一个同样的博客，！！！那个比较牛逼点呢','2019-05-08 18:13:50'),(18,'管理员',1665009812,'刚刚学做网站，厉害的人有很多','2019-05-09 13:20:58'),(19,'12',12,'                12','2019-05-09 16:25:09'),(20,'欧巴蔡蔡',2921959499,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/0.gif\" alt=\"[微笑]\">测测这个可以am','2019-05-09 16:39:29'),(21,'12312321321',12321321,'12321321321','2019-05-09 17:19:11'),(22,'sfsfsfas',19953060,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/14.gif\" alt=\"[亲亲]\">                ','2019-05-13 16:07:37'),(23,'啊哈',233516,'居然00后PHPer都出来咯。想当年，我开始学PHP的时候，就是2000年;D','2019-05-15 02:15:25'),(24,'213',132,'                312','2019-05-15 15:15:21'),(25,'草帽',1798359655,'首页搜索框下面的几个快捷文章标题文字长处长度后会与下一行重叠','2019-05-15 17:31:59'),(26,'呵呵',732128096,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/52.gif\" alt=\"[ok]\">                ','2019-05-16 11:27:44'),(27,'12312313',131231231231,'1231231231231','2019-05-16 16:18:53'),(28,'我的秀',213324234,'秀儿                ','2019-05-16 16:19:49'),(29,'11',732128096,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/26.gif\" alt=\"[怒]\">                ','2019-05-16 17:10:42'),(35,'dd',539688774,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/28.gif\" alt=\"[馋嘴]\"><img src=\"http://hzjsj.top/Public/ht/layui/images/face/63.gif\" alt=\"[给力]\">                ','2019-05-24 16:24:03'),(36,'Colin',811687790,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/2.gif\" alt=\"[哈哈]\">                ','2019-05-28 08:30:21'),(37,'lll',0,'                <img src=\"http://hzjsj.top/Public/ht/layui/images/face/53.gif\" alt=\"[耶]\">','2019-05-28 19:50:07'),(38,'筱笆',1165173111,'　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　<img src=\"http://hzjsj.top/Public/ht/layui/images/face/54.gif\" alt=\"[good]\">','2019-05-31 11:14:10'),(39,'牧马人',123123,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/16.gif\" alt=\"[太开心]\">                ','2019-05-31 16:12:35'),(40,'s\'s\'s',0,'s\'b\'v','2019-05-31 17:11:13'),(41,'哈哈',307495216,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/1.gif\" alt=\"[嘻嘻]\">                ','2019-05-31 20:29:04'),(42,'吃吃吃',2428691764,'<img src=\"http://hzjsj.top/Public/ht/layui/images/face/47.gif\" alt=\"[心]\">                ','2019-06-03 13:57:29'),(43,'wjy329',739468852,'bucuo','2019-06-03 20:41:13'),(44,'test',1655241471,'<p>文档用markdown写</p><p>代码支持高亮，这瞅着不咋好看</p>','2019-06-04 17:01:58'),(45,'good',12345,'<img src=\"https://hzjsj.top/Public/ht/layui/images/face/1.gif\" alt=\"[嘻嘻]\">                ','2019-06-13 12:12:18'),(46,'ceshi',1,'<img src=\"https://hzjsj.top/Public/ht/layui/images/face/63.gif\" alt=\"[给力]\">                ','2019-06-14 17:47:48'),(47,'仅有的回忆',2500621077,'<p># 测试</p><p>``` java</p><p>Hello Word</p><p>```</p>','2019-06-15 14:03:09'),(48,'fdsf',0,'<img src=\"https://hzjsj.top/Public/ht/layui/images/face/53.gif\" alt=\"[耶]\">                ','2019-06-15 15:46:25'),(49,'123',1111111,'你好                ','2019-06-17 16:00:30'),(50,'c as ',0,'asd&nbsp;','2019-06-19 17:44:29'),(51,'殷乘风',308144593,'                博主，你之前的聊天室模板不错，能分享一下吗','2019-06-21 11:48:41'),(52,'德玛西亚',1234,'<p>德玛西亚</p>                ','2019-06-26 15:39:17'),(53,'接口',70106377,'接口请求地址<a target=\"_blank\" href=\"http://jsonplaceholder.typicode.com/users\">http://jsonplaceholder.typicode.com/users</a>','2019-06-29 17:45:47'),(54,'asd001',1,'                <img src=\"https://hzjsj.top/Public/ht/layui/images/face/25.gif\" alt=\"[抱抱]\">','2019-07-02 17:54:48'),(55,'林阿三',1603889221,'<img src=\"https://hzjsj.top/Public/ht/layui/images/face/28.gif\" alt=\"[馋嘴]\">和博主一样都是00后','2019-07-04 06:43:35'),(56,'林阿三',1603889221,'<img src=\"https://hzjsj.top/Public/ht/layui/images/face/28.gif\" alt=\"[馋嘴]\">用一下路由把...','2019-07-04 06:45:50');
/*!40000 ALTER TABLE `tp3_message` ENABLE KEYS */;

#
# Structure for table "tp3_notice"
#

DROP TABLE IF EXISTS `tp3_notice`;
CREATE TABLE `tp3_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notice` varchar(255) DEFAULT NULL COMMENT '公告',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='公告';

#
# Data for table "tp3_notice"
#

/*!40000 ALTER TABLE `tp3_notice` DISABLE KEYS */;
INSERT INTO `tp3_notice` VALUES (1,'曾经拥有的，不要忘记；已经得到的，更要珍惜；属于自己的，不要放弃；已经失去的，留着回忆；想要得到的，必须努力；但最重要的，是好好爱惜自己！',1556806214),(2,'失败并不可怕，可怕的是你还相信这句话',1556806274),(3,'女孩子自信一点才漂亮，但是漂亮的女孩子谁不自信啊！',1556806294),(4,'人生就是这样，有欢笑也有泪水。一部分人主要负责欢笑，另一部分人主要负责泪水。',1556806394),(5,'总有一天，你会遇到一个好姑娘，她不要你的房，也不要你的车，不要钻石，更不要你的钱，当然她也不要你。',1556806442),(6,'秋天是收获的季节。别人的收获是成功与快乐，你的收获是认识到并不是每个人都会成功与快乐。',1556806467),(7,'这个世界没有错，谁让你长得不好看又没钱。',1556806498),(8,'成功其实很简单，就是当你坚持不住的时候，再坚持一下。',1556806553),(9,'我追逐自己的梦想，别人说我幼稚可笑，但我坚持了下来。最后发现，原来还真是我以前幼稚可笑。',1556806583),(10,'经过十年不断的努力和奋斗，我终于从一个懵懂无知的少年变成了一个懵懂无知的青年。',1556806604),(11,'留言页面新增分页，日记页面从数据库读取数据。',1564475313),(12,'整理了一下，上传到码云。',1567238315);
/*!40000 ALTER TABLE `tp3_notice` ENABLE KEYS */;

#
# Structure for table "tp3_user"
#

DROP TABLE IF EXISTS `tp3_user`;
CREATE TABLE `tp3_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `name` varchar(11) DEFAULT NULL COMMENT '账号',
  `password` char(32) DEFAULT NULL COMMENT '密码',
  `qq` bigint(20) DEFAULT NULL COMMENT 'QQ',
  `type` int(1) DEFAULT '0',
  `sex` tinyint(3) DEFAULT NULL COMMENT '男1，女2',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Data for table "tp3_user"
#

/*!40000 ALTER TABLE `tp3_user` DISABLE KEYS */;
INSERT INTO `tp3_user` VALUES (1,'管理员','admin','b359340e725abc0e9a35c829614a2075',70106377,1,1,1555734913),(2,'王秀龙','12345','610592870d2cd10b772d67e696fb3a20',70106377,0,1,1556803630);
/*!40000 ALTER TABLE `tp3_user` ENABLE KEYS */;
