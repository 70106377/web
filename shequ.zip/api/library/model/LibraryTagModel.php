<?php

namespace api\library\model;

use think\Model;

class LibraryTagModel extends Model
{



}