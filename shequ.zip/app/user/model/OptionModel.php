<?php

namespace app\user\model;
use think\Model;
class OptionModel extends Model{}