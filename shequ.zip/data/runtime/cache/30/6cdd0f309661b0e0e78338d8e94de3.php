<?php
//000000000000
 exit();?>
a:10:{s:9:"site_name";s:12:"后台管理";s:5:"'web'";s:20:"http://www.layui.com";s:3:"web";s:18:"http://127.0.1:915";s:5:"cache";s:1:"0";s:9:"file_type";s:28:"png|gif|jpg|jpeg|zip|rar|zip";s:10:"site_title";s:24:"通用后台管理系统";s:13:"site_keywords";s:9:"关键词";s:13:"site_descript";s:18:"后台管理系统";s:9:"copyright";s:38:"© 2018 计算机双创班 MIT license";s:8:"max_file";s:4:"1024";}