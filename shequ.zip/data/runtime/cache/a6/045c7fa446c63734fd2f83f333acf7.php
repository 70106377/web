<?php
//000000000000
 exit();?>
a:3:{s:9:"max_files";s:2:"20";s:10:"chunk_size";s:3:"512";s:10:"file_types";a:4:{s:5:"image";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:21:"jpg,jpeg,png,gif,bmp4";}s:5:"video";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:23:"mp4,avi,wmv,rm,rmvb,mkv";}s:5:"audio";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:11:"mp3,wma,wav";}s:4:"file";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:42:"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar";}}}