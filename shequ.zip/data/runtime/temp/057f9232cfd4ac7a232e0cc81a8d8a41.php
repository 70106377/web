<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:35:"themes/erp/admin\index\welcome.html";i:1568531812;}*/ ?>
welcome